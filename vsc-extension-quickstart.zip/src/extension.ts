// The module 'vscode' contains the VS Code extensibility API
// Import the module and reference it with the alias vscode in your code below
import * as vscode from 'vscode';

// this method is called when your extension is activated
// your extension is activated the very first time the command is executed
export function activate(context: vscode.ExtensionContext) {

	// Use the console to output diagnostic information (console.log) and errors (console.error)
	// This line of code will only be executed once when your extension is activated
	console.log('Congratulations, your extension "simple-integration" is now active!');
	const outputChannel = vscode.window.createOutputChannel(`My Test`);
	outputChannel.append('Test');
	outputChannel.show();

	context.subscriptions.push(
		vscode.commands.registerCommand('simple-integration.startSim', () => {
		  // Create and show a new webview
		  const panel = vscode.window.createWebviewPanel(
			'simpleIntegrationWindow', // Identifies the type of the webview. Used internally
			'Sim 1', // Title of the panel displayed to the user
			vscode.ViewColumn.One, // Editor column to show the new webview panel in.
			{} // Webview options. More on these later.
		  );

		  const { exec } = require('child_process');

		  const ls = exec('dir', function (error: any, stdout: any, stderr: any) {
		  if (error) {
			  console.log(error.stack);
			  console.log('Error code: '+error.code);
			  console.log('Signal received: '+error.signal);
		  }
		  	  //panel.webview.html = stdout;
				panel.webview.html = getWebviewContent();
			  outputChannel.append(stdout)
			  console.log('Child Process STDOUT: '+stdout);
			  console.log('Child Process STDERR: '+stderr);
		  });
	  
		  ls.on('exit', function (code: any) {
			  console.log('Child process exited with exit code '+code);
		  });

		})
	  );

	// The command has been defined in the package.json file
	// Now provide the implementation of the command with registerCommand
	// The commandId parameter must match the command field in package.json
	let disposable = vscode.commands.registerCommand('simple-integration.helloWorld', () => {
		// The code you place here will be executed every time your command is executed

		// Display a message box to the user
		vscode.window.showInformationMessage('Hello World from simple-integration!');
	});

	context.subscriptions.push(disposable);
}

function getWebviewContent() {
    return `<!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cat Coding</title>
    </head>
    <body>
    <img src="https://media.giphy.com/media/JIX9t2j0ZTN9S/giphy.gif" width="300" />
    </body>
    </html>`;
}

// this method is called when your extension is deactivated
export function deactivate() {}
